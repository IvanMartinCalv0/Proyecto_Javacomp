package Logica;

import java.io.Serializable;

/**
 *
 * @author ivan9
 */
public class Cliente_part extends Cliente_Usuario implements Serializable{
    
    private String dni; //dni del usuario
    
    /** Permite inicializar un objeto de tipo Cliente_part
     *
     * @param nombre  String
     * @param correo  String
     * @param clave  String
     * @param dni  String
     * @param direccion   Direccion
     * @param tarjeta  Tarjeta
     * @param telefono  String
     */
    public Cliente_part(String nombre, String correo, String clave, String dni, Direccion direccion, Tarjeta tarjeta, String telefono) {
        super(nombre, correo, clave, direccion, tarjeta, telefono);
        this.dni = dni;
    }

    
    //métodos

    /**Devuelve el DNI del ususaio
     *
     * @return    String
     */
    public String getDni() {
        return dni;
    }

    /**Da un nuevo valor al DNI
     *
     * @param dni    String
     */
    public void setDni(String dni) {
        this.dni = dni;
    }
    
    


    
}
