package Logica;

import Interfaz.Login;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JComboBox;
import org.jdatepicker.JDatePicker;

/**
 *
 * @author ivan9
 */
public class AppManagement {
    
    /**ArrayList que almacena los datos de los clientes empresa */
    public static ArrayList<Cliente_Emp> clientes_emp= new ArrayList<>();

    /**ArrayList que almacena los datos de los clientes particular  */
    public static ArrayList<Cliente_part> clientes_part= new ArrayList<>();
    
    /** ArrayList que almacena los datos de los productos */
    public static ArrayList<Producto> productos = new ArrayList<>();
    
    /** ArrayList que almacena los datos de las ventas que se han ealizado*/
    public static ArrayList<Registro_venta> registro = new ArrayList<>();
    
    /** ArrayList de los datos de los productos añadidos al carrito*/
    public static ArrayList<Venta> comprados = new ArrayList<>();

    
    //métodos

    /**Devuelve  ArrayList con el registro de ventas
     *
     * @return ArrayList
     */
    public static ArrayList<Registro_venta> getRegistro() {
        return registro;
    }

    /**Pone como registro el arrayList indicado
     *
     * @param registro  ArrayList
     */
    public static void setRegistro(ArrayList<Registro_venta> registro) {
        AppManagement.registro = registro;
    }

    /** Devuelve  ArrayList con el registro de ventas
     *
     * @return  ArrayList
     */
    public static ArrayList<Venta> getComprados() {
        return comprados;
    }

    /**Pone como carrito el arrayList indicado
     *
     * @param comprados  ArrayList
     */
    public static void setComprados(ArrayList<Venta> comprados) {
        AppManagement.comprados = comprados;
    } 
    
    /**  Devuelve  ArrayList con los usuarios de empesa
     *
     * @return  ArrayList
     * @throws IOException  Exception produced by failed or interrupted I/O operations
     * @throws java.io.FileNotFoundException Constructs a FileNotFoundException with null as its error detail message.
     * @throws java.lang.ClassNotFoundException   Tries to load a particular class but does not find it in the classpath
     */
    public static ArrayList<Cliente_Emp> getClientes_emp() throws IOException, FileNotFoundException, ClassNotFoundException {
        return clientes_emp;
    }

    /** Pone como clientes empresa el arrayList indicado
     *
     * @param clientes  ArrayList
     */
    public static void setClientes_emp(ArrayList<Cliente_Emp> clientes) {
        clientes_emp = clientes;
    }

    /**  Devuelve  ArrayList con los usuarios de particulares 
     *
     * @return  ArrayList
     * @throws java.io.IOException   Exception produced by failed or interrupted I/O operations
     * @throws java.io.FileNotFoundException Constructs a FileNotFoundException with null as its error detail message.
     * @throws java.lang.ClassNotFoundException   Tries to load a particular class but does not find it in the classpath
     */
    public static ArrayList<Cliente_part> getClientes_part() throws IOException, FileNotFoundException, ClassNotFoundException {
        return clientes_part;
    }

    /** Pone como clientes particulares el arrayList indicado
     *
     * @param clientes   ArrayList
     */
    public static void setClientes_part(ArrayList<Cliente_part> clientes) {
        clientes_part = clientes;
    }

    /**  Devuelve  ArrayList con los productos
     *
     * @return   ArrayList
     * @throws java.io.IOException   Exception produced by failed or interrupted I/O operations
     * @throws java.lang.ClassNotFoundException   Tries to load a particular class but does not find it in the classpath
     */
    public static ArrayList<Producto> getProductos() throws IOException, ClassNotFoundException {
        return productos;
    }

    /** Pone como productos el arrayList indicado
     *
     * @param prod   ArrayList
     */  
    public static void setProductos(ArrayList<Producto> prod) {
        productos = prod;
    }
    
    /**Da de alta un producto en comprados
     * 
     * @param prod  Producto que se quiere añadir al ArrayList
     */
    public static void altaProducto(Producto prod) {
        productos.add(prod);
    }

    
    
    /**Registra al nuevo cliente
     * 
     * @param cliente  Cliente que se quiere añadir al ArrayList
     */
    public static void registrarClientPart(Cliente_part cliente) {
        clientes_part.add(cliente);
    }

    /**  Añade un usuaio al ArrayList corespondiente
     *
     * @param cliente   Cliente_Emp class
     */
    public static void registrarClientEmp(Cliente_Emp cliente) {
        clientes_emp.add(cliente);
    }
    
    /**Elimina el usuario introducido
     * 
     * @param cliente Cliente que se quiere quitar al ArrayList
     */
    public static void bajaClientPart(Cliente_part cliente) {
        clientes_part.remove(cliente);
    }

    /** Da de baja un usuario
     *
     * @param cliente  Cliente que se quiere quitar al ArrayList
     */
    public static void bajaClientEmp(Cliente_Emp cliente) {
        clientes_emp.remove(cliente);
    }
    
    /**Da de baja un producto
     * 
     * @param prod Producto que se quiere quitar al ArrayList
     */
    public static void bajaProducto(Producto prod) {
        productos.remove(prod);
    }
    
    /**Da de alta una Compra en el registro
     * 
     * @param venta Compra que se quiere añadir al ArrayList de registro de ventas
     */
    public static void añadirReg(Registro_venta venta) {
        registro.add(venta);
    }
    
    
    /**Da de alta un producto en el carrito
     * 
     * @param venta Compra que se quiere añadir al ArrayList que representa al carrito
     */
    public static void añadirCarrito(Venta venta) {
        comprados.add(venta);
    }
    
    /**Da de baja un producto en el carrito
     * 
     * @param prod Compra que se quiere quitar al ArrayList que representa al carrito
     */
    public static void quitarCarrito(Venta prod) {
        comprados.remove(prod);
    }
    
    /**Vacia el carrito
     * 
     */
    public static void vaciarCarrito() {
        comprados = new ArrayList<>();
    }
    
    /**Lee los clientes que estan guardados en los respectivos archivos
     * 
     * @throws java.io.IOException   Exception produced by failed or interrupted I/O operations
     * @throws java.io.FileNotFoundException Constructs a FileNotFoundException with null as its error detail message.
     * @throws java.lang.ClassNotFoundException   Tries to load a particular class but does not find it in the classpath
     */
    public static void lecturaUsuarios() throws FileNotFoundException, IOException, ClassNotFoundException{
        FileInputStream fisPart = new FileInputStream("client_Part.dat");
        ObjectInputStream oisPart = new ObjectInputStream(fisPart);
        clientes_part = (ArrayList<Cliente_part>) oisPart.readObject();
        fisPart.close();
        FileInputStream fisEmp = new FileInputStream("client_Emp.dat");
        ObjectInputStream oisEmp = new ObjectInputStream(fisEmp );
        clientes_emp = (ArrayList<Cliente_Emp>) oisEmp .readObject();
        fisEmp.close();
        
        
    }
    /**Guarda los clientes en memoria
     * 
     * @throws java.io.IOException   Exception produced by failed or interrupted I/O operations
     * @throws java.io.FileNotFoundException Constructs a FileNotFoundException with null as its error detail message.
     */
    public static void guardarUsuariosEmp() throws FileNotFoundException, IOException{
        
        FileOutputStream fosEmp = new FileOutputStream("client_Emp.dat");
        ObjectOutputStream oosEmp = new ObjectOutputStream(fosEmp);
        oosEmp.writeObject(clientes_emp);
        
    }

    /**  Guarda los clientes en memoria
     *
     * @throws java.io.IOException   Exception produced by failed or interrupted I/O operations
     * @throws java.io.FileNotFoundException Constructs a FileNotFoundException with null as its error detail message.
     */
    public static void guardarUsuariosPart() throws FileNotFoundException, IOException{
        FileOutputStream fosPart = new FileOutputStream("client_Part.dat");
        ObjectOutputStream oosPart = new ObjectOutputStream(fosPart);
        oosPart.writeObject(clientes_part);
        
    }
    
    /** Guarda en el archivo los productos de los que se efectue la compra
     * 
     * @throws java.io.FileNotFoundException   Constructs a FileNotFoundException with null as its error detail message.
     */
    public static void guardarRegistro() throws FileNotFoundException, IOException{
        FileOutputStream fosReg = new FileOutputStream("Registro.dat");
        ObjectOutputStream oosReg = new ObjectOutputStream(fosReg);
        oosReg.writeObject(registro);
        
    }
    
    
    /**Lee los clientes que estan guardados en los respectivos archivos
     * 
     * @throws java.io.IOException   Exception produced by failed or interrupted I/O operations
     * @throws java.io.FileNotFoundException Constructs a FileNotFoundException with null as its error detail message.
     * @throws java.lang.ClassNotFoundException   Tries to load a particular class but does not find it in the classpath
     */
    public static void lecturaRegVentas() throws FileNotFoundException, IOException, ClassNotFoundException{
        FileInputStream fisReg = new FileInputStream("Registro.dat");
        ObjectInputStream oisReg = new ObjectInputStream(fisReg);
        registro = (ArrayList<Registro_venta>) oisReg.readObject();
        fisReg.close();
    }
    
    /**Genera un ticket a partir del nombre que se le introduce
     * 
     * @param c Cliente que realiza la compra
     * @param comprados  Lista de productos que se han añadido al carrito
     */
    
    public static void crearTicket(Cliente_Emp c, ArrayList<Venta> comprados){
        c.incNum_ticket();
         try {
            PrintWriter salida = new PrintWriter(new BufferedWriter(new FileWriter(c.getCorreo()+ String.valueOf(c.getNum_ticket())+".txt")));
            LocalDate date = LocalDate.now();
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            String dateStr = date.format(fmt);
            salida.println("    JAVACOMP");
            salida.println("Fecha : " + dateStr );
            salida.println("");
            salida.println("------Datos del Comprador------");
            salida.println("    ");
            salida.println("Nombre : " + c.getNombre());
            salida.println("CIF : " + c.getCif());
            salida.println("Tarjeta : " +c.getTarjeta().getDigitos());
            salida.println("Fecha de caducidad de la tarjeta: " + String.format("%1$tY-%1$tm-%1$td",c.getTarjeta().getFechacad()) );
            salida.println("WEB : " + c.getWeb());
            salida.println("Telefono : " + c.getTelefono());
            salida.println("Direccion: " + c.getDireccion().getCalle() +", nº" + c.getDireccion().getNum() + ", " + c.getDireccion().getCiudad());
            salida.println("-------Datos de la venta-------");
            salida.println("");
            for (int i=0; i<comprados.size();i++){
                salida.println(comprados.get(i).getNombre() + "........." + comprados.get(i).getCantidad()+"unidades" +"........." + String.valueOf(comprados.get(i).getImporte())+"€");
            }
            double importe = Math.round(importeTotal(comprados)*100)/100;
            salida.println("TOTAL : " + String.valueOf(importe)+"€");
            salida.println("");
            salida.println("GRACIAS POR SU COMPRA, VUELVA PRONTO");

            //Cerramos el stream
            salida.close();
        } catch (IOException ioe) {
            System.out.println("Error IO: " + ioe.toString());
        }
    }
    
    /**  Genera un ticket a partir del nombre que se le introduce
     *
     * @param c  Cliente que realiza la compra
     * @param comprados  Lista de productos que se han añadido al carrito
     */
    public static void crearTicket(Cliente_part c, ArrayList<Venta> comprados){
        c.incNum_ticket();
         try {
            PrintWriter salida = new PrintWriter(new BufferedWriter(new FileWriter(c.getCorreo()+ String.valueOf(c.getNum_ticket())+".txt")));
            LocalDate date = LocalDate.now();
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            String dateStr = date.format(fmt);
            salida.println("    JAVACOMP");
            salida.println("Fecha : " + dateStr );
            salida.println("");
            salida.println("------Datos del Comprador------");
            salida.println("    ");
            salida.println("Nombre : " + c.getNombre());
            salida.println("DNI : " + c.getDni());
            salida.println("Tarjeta : " +c.getTarjeta().getDigitos());
            salida.println("Fecha de caducidad de la tarjeta: " + String.format("%1$tY-%1$tm-%1$td",c.getTarjeta().getFechacad()) );
            salida.println("Telefono : " + c.getTelefono());
            salida.println("Direccion: " + c.getDireccion().getCalle() +", nº" + c.getDireccion().getNum() + ", " + c.getDireccion().getCiudad());
            salida.println("-------Datos de la venta-------");
            salida.println("");
            for (int i=0; i<comprados.size();i++){
                salida.println(comprados.get(i).getNombre() + "........." + comprados.get(i).getCantidad()+"unidades" +"........." + String.valueOf(comprados.get(i).getImporte())+"€");
            }
            double importe = Math.round(importeTotal(comprados)*100)/100;
            salida.println("TOTAL : " + String.valueOf(importe)+"€");
            salida.println("");
            salida.println("GRACIAS POR SU COMPRA, VUELVA PRONTO");

            //Cerramos el stream
            salida.close();
        } catch (IOException ioe) {
            System.out.println("Error IO: " + ioe.toString());
        }
    }
    
    /**Devuelve el importe total de la compra
     * @param comprados   Lista de productos que se han añadido al carrito
     * @return Devuelve el precio total de carrito incluyendo los gastos de envio
     */
    public static double importeTotal(ArrayList<Venta> comprados){
        double total = 0;
        for(int i=0; i<comprados.size();i++){
            total+= comprados.get(i).getImporte();
        }
        return  total+5;
    }
    
    /**Permite leer el fichero donde se guarda el listado de productos
     * 
     * @throws java.io.IOException   Exception produced by failed or interrupted I/O operations
     * @throws java.lang.ClassNotFoundException   Tries to load a particular class but does not find it in the classpath
     */
    
    public static void lecturaProductos() throws IOException, ClassNotFoundException{
        FileInputStream fisProd = new FileInputStream("Productos.dat");
        ObjectInputStream oisProd = new ObjectInputStream(fisProd );
        productos = (ArrayList<Producto>) oisProd.readObject();
        fisProd.close();
        
    }
    
    
     /**Guarda los cambios en los productos que hayan ocurridos tras la compra
     * 
     * @throws java.io.FileNotFoundException      Constructs a FileNotFoundException with null as its error detail message
     */
    public static void guardarProd() throws FileNotFoundException, IOException{
        FileOutputStream fosProd = new FileOutputStream("Productos.dat");
        ObjectOutputStream oosProd = new ObjectOutputStream(fosProd);
        oosProd.writeObject(productos);
    }
    
    /**Devuelve el nombre del usuaio que ha efectuado la compra
     * 
     * @param login  Pagina en la que se inicia sesión
     * @return  Devuelve el nombre del comprador que ha iniciado sesion
     */
    public static String comprador(Login login){
        boolean encontrado=false;
        int i=0;
        String nombre="";
        while((i<clientes_part.size())&&(!encontrado)){
            if(login.getCorreo().getText().equals(clientes_part.get(i).getCorreo())){
                encontrado = true;
                nombre =  (clientes_part.get(i).getNombre());
            }else{
                i++;
            }
        }
        i = 0;
        while((i<clientes_emp.size())&&(!encontrado)){
            if(login.getCorreo().getText().equals(clientes_emp.get(i).getCorreo())){
                encontrado = true;
                nombre = (clientes_emp.get(i).getNombre());
            }else{
                i++;
            }
        }
        return (nombre);
    }
    
    /** Determina si el correo introducido en el login corresponde a algun usuario que sea un particular
     * @param login Pagina en la que se inicia sesión
     * @return Devuelve un booleano de true o false
     */
    public static boolean esParticular(Login login){
        boolean particular = false;
        int i=0;
        while ((i<clientes_part.size())&&(!particular)){
            if (clientes_part.get(i).getCorreo().equals(login.getCorreo().getText())){
                particular = true;
            }else{
                i++;
            } 
        }
        return(particular);
    }
    
    /** Determina si el nombre seleccionado een el Combobox corresponde a algun usuario que sea un particular
     * @param nombre Nombre de la persona que ha iniciado sesion
     * @return Devuelve un booleano de true o false
     */
    public static boolean esParticular_nombre(String nombre){
        boolean particular = false;
        int i=0;
        while ((i<clientes_part.size())&&(!particular)){
            if (clientes_part.get(i).getNombre().equals(nombre)){
                particular = true;
            }else{
                i++;
            } 
        }
        return(particular);
    }
    
    
    
    /**Devuelve el usuario que a iniciado sesion si es un particular
     * 
     * @param login  Pagina en la que se inicia sesión
     * @return  Devuelve el cliente particular que ha iniciado sesión
     */
    public static Cliente_part usuarioDeseadoPart(Login login){
        boolean particular = false;
        int i=0;
        while ((i<clientes_part.size())&&(!particular)){
            if (clientes_part.get(i).getCorreo().equals(login.getCorreo().getText())){
                particular = true;
            }else{
                i++;
            } 
        }
        return(clientes_part.get(i));
    }
    
    /**Devuelve el usuario que a iniciado sesion si es una empresa
     * 
     * @param login  Pagina en la que se inicia sesión
     * @return  Devuelve el cliente empresa que ha iniciado sesión
     */
    public static Cliente_Emp usuarioDeseadoEmp(Login login){
        boolean particular = false;
        int i=0;
        while ((i<clientes_emp.size())&&(!particular)){
            if (clientes_emp.get(i).getCorreo().equals(login.getCorreo().getText())){
                particular = true;
            }else{
                i++;
            } 
        }
        return(clientes_emp.get(i));
    }
    
    /**Convierte la lista de usuarios en una unica Array de Strings para poder introducilo en el ComboBox
     * @return  Devuelve un String[] que contiene los nombres de los usuaios
    */
    public static String[] usuarios_a_Array(){
        String nombres="- - -,";
        for(int i=0; i<clientes_part.size();i++){
            nombres+= (clientes_part.get(i).getNombre()+",");
        }
        for(int i=0; i<clientes_emp.size();i++){
            nombres+= (clientes_emp.get(i).getNombre()+",");
        }
        return nombres.split(",");
    }
    
    /**Devuelve el usuaio seleccionado
     * 
     * @param cbUsuarios  ComboBox que contiene el nombre de los usuarios
     * @return Devuelve el cliente que este seleccionado en el ComboBox
     */
    public static Cliente_part busca_UsuariosPart(JComboBox cbUsuarios){
        boolean encontrado=false;
        int i=0;
        while((i<clientes_part.size())&&(!encontrado)){
            if(cbUsuarios.getSelectedItem().equals(clientes_part.get(i).getNombre())){
                encontrado=true;
            }else{
                i++;
            }
        }
        return clientes_part.get(i);
        
    }
    
    /** Devuelve el usuario que esta seleccionado en el combobox
     *
     * @param cbUsuarios   Combobox de usuarios
     * @return usuario que esta seleccionado en el combobox
     */
    public static Cliente_Emp busca_UsuariosEmp(JComboBox cbUsuarios){
        boolean encontrado=false;
        int i=0;
        while((i<clientes_emp.size())&&(!encontrado)){
            if(cbUsuarios.getSelectedItem().equals(clientes_emp.get(i).getNombre())){
                encontrado=true;
            }else{
                i++;
            }
        }
        return clientes_emp.get(i);
    }
    
    
    
    /**Devuelve un ArrayList con los productos posteriores a la fecha seleccionada en el DatePicker
     * 
     * @param fecha_filtro  Fecha seleccionado en el JDatePicker
     * @return Ventas posteriores a la fecha señalada
     */
    
    public static ArrayList<Registro_venta> ventasPosteriores(JDatePicker fecha_filtro){
        ArrayList<Registro_venta> ventas = new ArrayList<>();
        Date fecha = ((GregorianCalendar) fecha_filtro.getModel().getValue()).getTime();
        
        for(int i = 0; i<registro.size(); i++){
            if(registro.get(i).getFecha().after(fecha)){
                ventas.add(registro.get(i));
            }
        }
        return ventas;
    }
}
