package Logica;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author ivan9
 */
public class Registro_venta implements Serializable{
    private double importe; //importe de la venta
    private Date fecha; //fecha en la que se ha efectuado la venta
    private String comprador; //ususario qque la ha efectuado
    private String correo; // correo de dicho usuario

    /**  Permite inicializar un objeto de la clase Registro_venta
     *
     * @param importe  double
     * @param comprador  String
     * @param correo  String
     */
    public Registro_venta(double importe, String comprador, String correo) {
        this.importe = importe;
        Calendar calendar = Calendar.getInstance();
        this.fecha = calendar.getTime();
        this.comprador = comprador;
        this.correo= correo;
    }

    //métodos

    /** Devuelve el valor del Importe
     *
     * @return  double
     */
    public double getImporte() {
        return importe;
    }

    /** Da un valor al Importe
     *
     * @param importe  double
     */
    public void setImporte(double importe) {
        this.importe = importe;
    }

    /**  Devuelve el valor de la fecha
     *
     * @return  Date
     */
    public Date getFecha() {
        return fecha;
    }

    /**  Da un valor al Fecha
     *
     * @param fecha  Date
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    /**Devuelve el valor del Comprador
     *
     * @return   String
     */
    public String getComprador() {
        return comprador;
    }

    /**  Da un valor al Comprador
     *
     * @param comprador  String
     */
    public void setComprador(String comprador) {
        this.comprador = comprador;
    }

    /** Devuelve el valor del ICorreo
     *
     * @return  String
     */
    public String getCorreo() {
        return correo;
    }

    /** Da un valor a Correo
     *
     * @param correo  String
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    
}
