
package Logica;

import java.io.Serializable;

/**
 *
 * @author ivan9
 */
public class Cliente_Usuario implements Serializable{
    private String nombre; //nombre del usuario
    private String correo; // correo asignado
    private String clave; //clave de la cuenta
    private Direccion direccion; // direccion del usuario
    private Tarjeta tarjeta; //tarjeta del usuario
    private String telefono; //telefono del usuario
    private int num_ticket; //numero de compras realizadas

    /**Permite inicializar un objeto de tipo Cliente_Usuario
     *
     * @param nombre   String
     * @param correo   String
     * @param clave   String
     * @param direccion   Direccion
     * @param tarjeta    Tarjeta
     * @param telefono  String
     */
    public Cliente_Usuario(String nombre, String correo, String clave, Direccion direccion, Tarjeta tarjeta, String telefono) {
        this.nombre = nombre;
        this.correo = correo;
        this.clave = clave;
        this.direccion = direccion;
        this.tarjeta = tarjeta;
        this.telefono = telefono;
        this.num_ticket = 0;
    }

    //métodos

    /**Devueve el Nombre del usuario
     * 
     * @return   String
     */
    public String getNombre() {
        return nombre;
    }

    /** Da un nuevo valo al nombre
     *
     * @param nombre   String
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**Devueve el correo del usuario
     *
     * @return   String
     */
    public String getCorreo() {
        return correo;
    }

    /**Da un nuevo valo al correo
     *
     * @param correo   String
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**Devueve la clave del usuario
     *
     * @return   String
     */
    public String getClave() {
        return clave;
    }

    /** Da un nuevo valo a la clave
     *
     * @param clave  String
     */
    public void setClave(String clave) {
        this.clave = clave;
    }

    /**Devueve la direccion del usuario
     *
     * @return   Direccion
     */
    public Direccion getDireccion() {
        return direccion;
    }

    /**  Da un nuevo valo a la direccion
     *
     * @param direccion   Direccion
     */
    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    /**Devueve la tarjeta del usuario
     *
     * @return   Tarjeta
     */
    public Tarjeta getTarjeta() {
        return tarjeta;
    }

    /**  Da un nuevo valo a la Tarjeta
     *
     * @param tarjeta   Tarjeta
     */
    public void setTarjeta(Tarjeta tarjeta) {
        this.tarjeta = tarjeta;
    }

    /**Devueve el Telefono del usuario
     *
     * @return   String
     */
    public String getTelefono() {
        return telefono;
    }

    /**Da un nuevo valo al telefono
     *
     * @param telefono  String
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**Devueve el numero de ticket del usuario
     *
     * @return   String
     */
    public int getNum_ticket() {
        return num_ticket;
    }

    /**Da un nuevo valo al numero de tickets
     *
     * @param num_ticket   String
     */
    public void setNum_ticket(int num_ticket) {
        this.num_ticket = num_ticket;
    }
    
    /**Aumenta en uno el numero de tickets
     *
     */
    public void incNum_ticket() {
        this.num_ticket +=1;
    }
    
}
