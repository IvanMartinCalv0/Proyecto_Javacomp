package Logica;

import java.io.Serializable;

/**
 *
 * @author ivan9
 */
public class Direccion implements Serializable{
    private String cp; //codigo postal
    private String num; //numero de la direccion
    private String ciudad; //ciudad de la direccion
    private String calle; // calle de la direccion

    /**  Permite inicializar un objeto de tipo Direccion
     *
     * @param cp  String
     * @param num  String
     * @param ciudad  String
     * @param calle  String
     */
    public Direccion(String cp, String num, String ciudad, String calle) {
        this.cp = cp;
        this.num = num;
        this.ciudad = ciudad;
        this.calle = calle;
    }

    
    //métodos

    /** Devuelve el valor de la calle
     *
     * @return  String
     */
    public String getCalle() {
        return calle;
    }

    /** Da un nuevo valor a la calle
     *
     * @param calle  String
     */
    public void setCalle(String calle) {
        this.calle = calle;
    }

    /** Devuelve el valor del codigo postal
     *
     * @return  String
     */
    public String getCp() {
        return cp;
    }

    /** Da un nuevo valor al codigo postal
     *
     * @param cp  String
     */
    public void setCd(String cp) {
        this.cp = cp;
    }

    /** Devuelve el valor del numero de la vivienda
     *
     * @return  String
     */
    public String getNum() {
        return num;
    }

    /** Da un nuevo valor al numero
     *
     * @param num  String
     */
    public void setNum(String num) {
        this.num = num;
    }

    /**  Devuelve el valor de la ciudad
     *
     * @return  String
     */
    public String getCiudad() {
        return ciudad;
    }

    /** Da un nuevo valor a la ciudad
     *
     * @param ciudad  String
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    
    
}
