package Logica;

import java.io.Serializable;

/**
 *
 * @author ivan9
 */
public class Cliente_Emp extends Cliente_Usuario implements Serializable{
    private String cif; //cif de la empresa
    private String web; //web de la empresa

    /**Permite inicializar un objeto de tipo Cliente_Empresa
     *
     * @param nombre  String
     * @param correo  String
     * @param clave   String
     * @param cif    String
     * @param direccion  Direccion
     * @param tarjeta    Tarjeta
     * @param web   String
     * @param telefono   String
     */
    public Cliente_Emp(String nombre, String correo, String clave, String cif,  Direccion direccion, Tarjeta tarjeta, String web, String telefono) {
        super(nombre, correo, clave, direccion, tarjeta, telefono);
        this.cif = cif;
        this.web = web;
    }

    
    //métodos

    /**Devuelve la web del usuario
     *
     * @return  String
     */

    public String getWeb() {
        return web;
    }

    /**Pone una nueva webb al usuaio
     *
     * @param web  String
     */
    public void setWeb(String web) {
        this.web = web;
    }

    /** Devuelve el CIF de la empresa
     *
     * @return String
     */
    public String getCif() {
        return cif;
    }

    /**Pone un nuevo CIF a la empresa
     *
     * @param cif  String
     */
    public void setCif(String cif) {
        this.cif = cif;
    }
    
    
}
