package Logica;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author ivan9
 */
public class Tarjeta implements Serializable{
    private String titular; //titular de la tarjeta
    private String digitos; //16 digitos de seguridad
    private Date fechacad;   // fecha de caducidad
    
    /**  Permite inicializar un objeto de la clase Tarjeta
     *
     * @param titular  String
     * @param digitus  String
     * @param fechacad  Date
     */
    public Tarjeta(String titular, String digitus, Date fechacad) {
        this.titular = titular;
        this.digitos = digitus;
        this.fechacad = fechacad;
    }
    
    
    //métodos

    /**  Devueleve el valor del titular
     *
     * @return  String
     */
    public String getTitular() {
        return titular;
    }

    /**  Da un valor al Titular
     *
     * @param titular  String
     */
    public void setTitular(String titular) {
        this.titular = titular;
    }

    /**  Devueleve el valor de Digitos
     *
     * @return  String
     */
    public String getDigitos() {
        return digitos;
    }

    /**  Da un valor a los digitos de la tarjeta
     *
     * @param digitus  String
     */
    public void setDigitos(String digitus) {
        this.digitos = digitus;
    }

    /** Devueleve el valor de la fecha de caducidad
     *
     * @return  Date
     */
    public Date getFechacad() {
        return fechacad;
    }

    /** Da un valor a la fecha de caducidad
     *
     * @param fechacad  Date
     */
    public void setFechacad(Date fechacad) {
        this.fechacad = fechacad;
    }

    

}
