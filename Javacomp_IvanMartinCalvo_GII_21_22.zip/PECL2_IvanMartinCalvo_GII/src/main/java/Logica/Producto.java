package Logica;

/**
 *
 * @author ivan9
 */

import java.io.Serializable;
import java.time.*;
import java.util.*;
import javax.swing.ImageIcon;

/**
 *
 * @author ivan9
 */
public class Producto  implements Serializable{
    private String titulo_prod; //titulo del producto
    private String caracteristicas; //caracteristicas del producto
    private String categoria; // categoria a la que pertenece
    private double precio; //precio de venta del producto
    private int stock; //cantidad a la venta
    private LocalDate fecha_dalta; // cuando se ha registrado
    private ArrayList<Opinion> opin; //lista de opiniones dadas por los usuarios
    private ImageIcon imagen; //imagen asignada
    private String ruta; //ruta de la imagen asignada

    /**Permite inicializar un objeto de la clase Producto
     *
     * @param titulo_prod   String
     * @param caracteristicas   String
     * @param categoria   String
     * @param precio  double
     * @param stock  int
     * @param ruta   String
     */
    public Producto(String titulo_prod, String caracteristicas, String categoria, double precio, int stock, String ruta) {
        this.titulo_prod = titulo_prod;
        this.caracteristicas = caracteristicas;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
        this.fecha_dalta = LocalDate.now();
        this.opin =  new ArrayList<>();
        this.imagen = new ImageIcon(ruta);
        this.ruta = ruta;
    }

    //métodos

    /**Devuelve el valor del titulo del producto
     *
     * @return    String
     */
    public String getTitulo_prod() {
        return titulo_prod;
    }

    /** Da un valor al titulo del producto
     *
     * @param titulo_prod   String
     */
    public void setTitulo_prod(String titulo_prod) {
        this.titulo_prod = titulo_prod;
    }

    /** Devuelve el valor de las caracteristicas
     *
     * @return   String
     */
    public String getCaracteristicas() {
        return caracteristicas;
    }

    /** Da un valor a las caracteristicas
     *
     * @param caracteristicas   String
     */
    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }

    /** Devuelve el valor de la categoria
     *
     * @return   String
     */
    public String getCategoria() {
        return categoria;
    }

    /** Da un valor a la categoria
     *
     * @param categoria   String
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    /** Devuelve el valor del precio
     *
     * @return  double
     */
    public double getPrecio() {
        return precio;
    }

    /** Da un valor al precio
     *
     * @param precio   double
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /** Devuelve el valor del stock
     *
     * @return  int
     */
    public int getStock() {
        return stock;
    }

    /** Da un valor para el stock
     *
     * @param stock  int
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**  Devuelve el valor de la fecha de alta
     *
     * @return   LocalDate
     */
    public LocalDate getFecha_dalta() {
        return fecha_dalta;
    }

    /**Da un valor a la fecha de alta
     *
     * @param fecha_dalta   LocalDate
     */
    public void setFecha_dalta(LocalDate fecha_dalta) {
        this.fecha_dalta = fecha_dalta;
    }

    /**  Devuelve el valor del ArrayList de opiniones
     *
     * @return  ArrayList
     */
    public ArrayList<Opinion> getOpin() {
        return opin;
    }
    
    /** Añade una Opinion al ArrayList
     *
     * @param opin   Opinion
     */
    public void darOpinion(Opinion opin){
       
        this.opin.add(opin);
       
   } 

    /**  Quita una Opinion al ArrayList
     *
     * @param opin  Opinion
     */
    public void quitarOpinion(Opinion opin){
       
        this.opin.remove(opin);  
   }

    /** Devuelve el ImagenIcon asignada
     *
     * @return   ImageIcon
     */
    public ImageIcon getImagen() {
        return imagen;
    }

    /**  Da un valor a la imagen
     *
     * @param imagen  ImageIcon
     */
    public void setImagen(ImageIcon imagen) {
        this.imagen = imagen;
    }

    /** Devuelve  el valor de la ruta
     * 
     * @return   String
     */
    public String getRuta() {
        return ruta;
    }

    /** Da un valor a la ruta
     *
     * @param ruta  String
     */
    public void setRuta(String ruta) {
        this.ruta = ruta;
    }
    
    

    /**Calcula la media de la valoracion de un productos
     * @return  double
     */
    
    public double media(){
        int tamaño= this.getOpin().size();
        double suma=0;
        for (int i=0; i< tamaño;i++){
            suma+= this.getOpin().get(i).getCalificacion();
        }
        return (suma/tamaño);
    }
   
   
}
