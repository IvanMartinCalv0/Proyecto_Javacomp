package Logica;

import java.io.Serializable;


/**
 *
 * @author ivan9
 */
public class Venta implements Serializable{
    private String nombre; //nombre del producto
    private double importe;//importe total = cantidad * precio
    private int cantidad;// cuantos productos de este tipo se selecciona
    private double precio;// precio unitario

    /** Permite inicializar un objeto de la clase Venta
     *
     * @param nombre  String
     * @param importe   double
     * @param cantidad   int
     * @param precio  double
     */
    public Venta(String nombre, double importe, int cantidad, double precio) {
        this.nombre = nombre;
        this.importe = importe;
        this.cantidad = cantidad;
        this.precio = precio;
    }
    
    //métodos

    /** Devuelve el valor del Nombre
     *
     * @return    String
     */
    public String getNombre() {
        return nombre;
    }

    /**  Da el valor al Nombre
     *
     * @param nombre    String
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**  Devuelve el valor del Nombre
     *
     * @return   double
     */
    public double getImporte() {
        return importe;
    }

    /** Da el valor al Importe
     *
     * @param importe   double
     */
    public void setImporte(double importe) {
        this.importe = importe;
    }

    /**  Devuelve el valor de la Cantidad
     *
     * @return  int
     */
    public int getCantidad() {
        return cantidad;
    }

    /** Da el valor a la Cantidad
     *
     * @param cantidad   int
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    /**   Devuelve el valor del Precio
     *
     * @return   double
     */
    public double getPrecio() {
        return precio;
    }

    /** Da el valor al Precio
     *
     * @param precio  double
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    
    
}
