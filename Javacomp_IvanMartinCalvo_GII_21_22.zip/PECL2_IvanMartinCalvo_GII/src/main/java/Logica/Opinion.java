package Logica;

/**
 *
 * @author ivan9
 */
import java.io.Serializable;
import java.time.*;

/**
 *
 * @author ivan9
 */
public class Opinion implements Serializable {
    private int calificacion; //nota dada al producto
    private String comentario; //comentario del producto
    private LocalDate fecha; //fecha en la que se ha dado

    /**Permite inicializar un objeto de la clase Opinion
     *
     * @param calificacion
     * @param comentario  String
     */
    public Opinion(int calificacion, String comentario) {
        this.calificacion = calificacion;
        this.comentario = comentario;
        this.fecha = LocalDate.now();
    }

    //métodos

    /**  Devuelve el valor de la calificacion
     *
     * @return  int
     */
    public int getCalificacion() {
        return calificacion;
    }

    /** Da un valor a la calificacion
     *
     * @param calificacion   int
     */
    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    /**  Devuelve el valor del comentario
     *
     * @return  String
     */
    public String getComentario() {
        return comentario;
    }

    /** Da un valor al comentario
     *
     * @param comentario  String
     */
    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    /**  Devuelve el valor de la fecha
     *
     * @return  LocalDate
     */
    public LocalDate getFecha() {
        return fecha;
    }

    /** Da un valor a la fecha de la valoracion
     *
     * @param fecha  LocalDate
     */
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
    
    
    
}
